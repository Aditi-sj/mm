package com.shalem.movieservice.entity;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Movie {

    private Long rank;
    private String title;

    private String description;

    private String image;

    private String big_image;

    private List<String> genre;

    private String thumbnail;

    private String rating;

    private String id;

    private Long year;

    private String imdbid;

    private String imdb_link;

}

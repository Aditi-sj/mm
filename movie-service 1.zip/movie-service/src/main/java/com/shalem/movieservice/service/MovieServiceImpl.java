package com.shalem.movieservice.service;

import com.shalem.movieservice.entity.Movie;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
@Slf4j
public class MovieServiceImpl implements MovieService{
    @Autowired
    private RestTemplate restTemplate;
    @Value("${external.header.rapidapi.key}")
    private String rapidAPi_Key;
    @Value("${external.header.rapidapi.value}")
    private String rapidAPi_Key_value;

    @Value("${external.header.rapid.host.key}")
    private String rapidAPi_host;
    @Value("${external.header.rapid.host.value}")
    private String rapidAPi_host_value;
    @Value("${external.api}")
    private String externalAPI;
    @Override
    public List<Movie> getALlMovies() throws Exception {

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.set(rapidAPi_Key, rapidAPi_Key_value);
        headers.set(rapidAPi_host, rapidAPi_host_value);
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        long start = System.currentTimeMillis();
        try{
            ResponseEntity<List<Movie>> resp=restTemplate.exchange(externalAPI, HttpMethod.GET, entity, new ParameterizedTypeReference<List<Movie>>() {});
            log.info(resp.getBody().toString());
            long end = System.currentTimeMillis();
            log.info("Time took for fetching "+(end-start));
            return resp.getBody();
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    @Override
    public Movie getMovieByRank(long rank) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.set(rapidAPi_Key, rapidAPi_Key_value);
        headers.set(rapidAPi_host, rapidAPi_host_value);
        headers.set("content-type","application/json");
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        long start = System.currentTimeMillis();
        try{
            ResponseEntity<Movie> resp=restTemplate.exchange(externalAPI+"/top"+rank, HttpMethod.GET, entity,Movie.class);
            log.info(resp.getBody().toString());
            long end = System.currentTimeMillis();
            log.info("Time took for fetching "+(end-start));
            return resp.getBody();
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }
}
